<?php include "header.php"; ?>
<div class="container">
	<aside class="col-1">
	<div class="profile__aside">
		<p>HOANG NGUYEN</p>
	</div>

	<nav class="nav__aside">
	<ul>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
	</ul>
	</nav>
	</aside>	
	<main class="col-2">

	</main>	
</div>
<?php include "footer.php"; ?>